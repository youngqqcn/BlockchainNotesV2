#!/bin/bash
curl http://localhost:26657/broadcast_tx_commit?tx=0x68656c6c6f